/**
 * 
 */
package com.zhujiahui.util;

import java.util.Arrays;
import java.util.Random;

import org.ujmp.core.Matrix;
import org.ujmp.core.MatrixFactory;

/**
 * @author ZhuJiahui705
 *
 */
public class MatrixUtils {

	
	public static double[][] init2DDoubleArray(int dimension1, int dimension2, double value) {
		double[][] result = new double[dimension1][dimension2];
		
		for (int i = 0; i < dimension1; i++) {
			for (int j = 0; j < dimension2; j++) {
				result[i][j] = value;
			}
		}
		
		return result;
	}
	
	public static double[][] randUniform2D(int m, int n, double scalar) {
		double[][] result = new double[m][n];
		Random rd = new Random();
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++) {
				result[i][j] = rd.nextDouble();
			}
		}
		return result;
	}
	
	
	public static double[][] matrixNormalizeByRow(double[][] a) {
		int rowNum = a.length;
		int columnNum = a[0].length;		
		double[][] result = new double[rowNum][columnNum];

		for (int i = 0; i < rowNum; i++) {
			double rowSum = arraySum(a[i]);
			for (int j = 0; j < columnNum; j++) {
				result[i][j] = a[i][j] / rowSum;
			}
		}
		return result;
	}
	
	
	public static double[][] subMatrix(double[][] a, int rowStart, int rowEnd, int columnStart, int columnEnd) {
		int rowNum = rowEnd - rowStart + 1;
		int columnNum = columnEnd - columnStart + 1;
		double[][] result = new double[rowNum][columnNum];
		
		for (int i = 0; i < rowNum; i++) {
			for (int j = 0; j < columnNum; j++) {
				result[i][j] = a[rowStart + i][columnStart + j];
			}
		}
		
		return result;
	}
	
	
	public static double[] getColumnTo1D(double[][] a, int columnNum) {

		double[] result = new double[a.length];
		
		for (int i = 0; i < a.length; i++) {
			result[i] = a[i][columnNum];
		}
		
		return result;
	}
	
	
	public static double[][] getRows(double[][] a, int rowStart, int rowEnd) {
		int rowNum = rowEnd - rowStart + 1;
		int columnNum = a[0].length;
		double[][] result = new double[rowNum][columnNum];
		
		for (int i = 0; i < rowNum; i++) {
			for (int j = 0; j < columnNum; j++) {
				result[i][j] = a[rowStart + i][j];
			}
		}
		
		return result;
	}
	
	public static double[][] getColumns(double[][] a, int columnStart, int columnEnd) {
		int rowNum = a.length;
		int columnNum = columnEnd - columnStart + 1;
		double[][] result = new double[rowNum][columnNum];
		
		for (int i = 0; i < rowNum; i++) {
			for (int j = 0; j < columnNum; j++) {
				result[i][j] = a[i][columnStart + j];
			}
		}
		
		return result;
	}
	
	
	public static double[][] toRowDouble2D(double[] a) {

		double[][] result = new double[1][a.length];
		
		for (int i = 0; i < a.length; i++) {
			result[0][i] = a[i];
		}
		
		return result;
	}
	
	
	public static double[][] toColumnDouble2D(double[] a) {

		double[][] result = new double[a.length][1];
		
		for (int i = 0; i < a.length; i++) {
			result[i][0] = a[i];
		}
		
		return result;
	}
	
	public static double[][] toColumnDouble2D(double a) {

		double[][] result = new double[1][1];		
		result[0][0] = a;		
		return result;
	}
	
	
	public static double[][] matrixSum(double[][] a, double[][] b) {
		int rowNum = a.length;
		int columnNum = a[0].length;
		double[][] result = new double[rowNum][columnNum];
		
		for (int i = 0; i < rowNum; i++) {
			for (int j = 0; j < columnNum; j++) {
				result[i][j] = a[i][j] + b[i][j];
			}
		}
		
		return result;
	}
	
	
	public static double[][] matrixSum(double[][] a, double b) {
		int rowNum = a.length;
		int columnNum = a[0].length;
		double[][] result = new double[rowNum][columnNum];
		
		for (int i = 0; i < rowNum; i++) {
			for (int j = 0; j < columnNum; j++) {
				result[i][j] = a[i][j] + b;
			}
		}
		
		return result;
	}
	
	
	public static double matrixSumAll(double[][] a) {
		int rowNum = a.length;
		int columnNum = a[0].length;
		double result = 0.0;
		
		for (int i = 0; i < rowNum; i++) {
			for (int j = 0; j < columnNum; j++) {
				result += a[i][j];
			}
		}
		
		return result;
	}
	
	
	public static double[][] matrixSumByRow(double[][] a) {
		int rowNum = a.length;
		int columnNum = a[0].length;
		double[][] result = new double[rowNum][1];
		
		for (int i = 0; i < rowNum; i++) {
			result[i][0] = 0;
			for (int j = 0; j < columnNum; j++) {
				result[i][0] += a[i][j];
			}
		}
		
		return result;
	}
	
	public static double[] matrixSumByRow2(double[][] a) {
		int rowNum = a.length;
		int columnNum = a[0].length;
		double[] result = new double[rowNum];
		
		for (int i = 0; i < rowNum; i++) {
			result[i] = 0;
			for (int j = 0; j < columnNum; j++) {
				result[i] += a[i][j];
			}
		}
		
		return result;
	}
	
	public static double[][] matrixSumByColumn(double[][] a) {
		int rowNum = a.length;
		int columnNum = a[0].length;
		double[][] result = new double[1][columnNum];
		
		for (int j = 0; j < columnNum; j++) {
			result[0][j] = 0;
			for (int i = 0; i < rowNum; i++) {
				result[0][j] += a[j][i];
			}
		}
		
		return result;
	}
	
	public static double[][] matrixMinus(double[][] a, double[][] b) {
		int rowNum = a.length;
		int columnNum = a[0].length;
		double[][] result = new double[rowNum][columnNum];
		
		for (int i = 0; i < rowNum; i++) {
			for (int j = 0; j < columnNum; j++) {
				result[i][j] = a[i][j] - b[i][j];
			}
		}
		
		return result;
	}
	
	
	public static double[][] matrixMinus(double[][] a, double b) {
		int rowNum = a.length;
		int columnNum = a[0].length;
		double[][] result = new double[rowNum][columnNum];
		
		for (int i = 0; i < rowNum; i++) {
			for (int j = 0; j < columnNum; j++) {
				result[i][j] = a[i][j] - b;
			}
		}
		
		return result;
	}
	
	
	public static double[][] matrixMultiplyByElement(double[][] a, double[][] b) {
		int rowNum = a.length;
		int columnNum = a[0].length;
		double[][] result = new double[rowNum][columnNum];
		
		for (int i = 0; i < rowNum; i++) {
			for (int j = 0; j < columnNum; j++) {
				result[i][j] = a[i][j] * b[i][j];
			}
		}
		
		return result;
	}
	
	
	public static double[][] matrixMultiplyByScalar(double[][] a, double b) {
		int rowNum = a.length;
		int columnNum = a[0].length;
		double[][] result = new double[rowNum][columnNum];
		
		for (int i = 0; i < rowNum; i++) {
			for (int j = 0; j < columnNum; j++) {
				result[i][j] = a[i][j] * b;
			}
		}
		
		return result;
	}
	
	
	public static double[][] linearMatrixMultiply(double[][] a, double b, double c) {
		int rowNum = a.length;
		int columnNum = a[0].length;
		double[][] result = new double[rowNum][columnNum];
		
		for (int i = 0; i < rowNum; i++) {
			for (int j = 0; j < columnNum; j++) {
				result[i][j] = a[i][j] * b + c;
			}
		}
		
		return result;
	}
	
	
	public static double[][] matrixDivideByElement(double[][] a, double[][] b) {
		int rowNum = a.length;
		int columnNum = a[0].length;
		double[][] result = new double[rowNum][columnNum];
		
		for (int i = 0; i < rowNum; i++) {
			for (int j = 0; j < columnNum; j++) {
				result[i][j] = a[i][j] / b[i][j];
			}
		}
		
		return result;
	}
	
	
	public static double[][] matrixDivideByScalar(double[][] a, double b) {
		int rowNum = a.length;
		int columnNum = a[0].length;
		double[][] result = new double[rowNum][columnNum];
		
		for (int i = 0; i < rowNum; i++) {
			for (int j = 0; j < columnNum; j++) {
				result[i][j] = a[i][j] / b;
			}
		}
		
		return result;
	}
	
	
	public static double normFrobenius(double[][] a) {
		int rowNum = a.length;
		int columnNum = a[0].length;
		double result = 0.0;
		
		for (int i = 0; i < rowNum; i++) {
			for (int j = 0; j < columnNum; j++) {
				result += (a[i][j] * a[i][j]);
			}
		}
		
		return Math.sqrt(result);
	}
	
	
	public static double squareResidual(double[][] a, double[][] b) {
		int rowNum = a.length;
		int columnNum = a[0].length;
		double result = 0.0;
		
		for (int i = 0; i < rowNum; i++) {
			for (int j = 0; j < columnNum; j++) {
				result += ((a[i][j] - b[i][j]) * (a[i][j] - b[i][j]));
			}
		}
		
		return Math.sqrt(result);
	}
	
	public static double[][] transpose(double[][] a) {
		int rowNum = a.length;
		int columnNum = a[0].length;
		double[][] result = new double[columnNum][rowNum];
		
		for (int i = 0; i < rowNum; i++) {
			for (int j = 0; j < columnNum; j++) {
				result[j][i] = a[i][j];
			}
		}
		
		return result;
	}
	
	public static double[] arraySum(double[] a, double[] b) {

		double[] result = new double[a.length];
		
		for (int i = 0; i < a.length; i++) {
			result[i] = a[i] + b[i];
		}
		
		return result;
	}
	
	public static double arraySum(double[] a) {

		double result = 0;
		
		for (int i = 0; i < a.length; i++) {
			result += a[i];
		}
		
		return result;
	}
	
	public static double[] arraySumByScalar(double[] a, double b) {

		double[] result = new double[a.length];
		
		for (int i = 0; i < a.length; i++) {
			result[i] = a[i] + b;
		}
		
		return result;
	}
	
	
	public static double arraySumByScalarAll(double[] a, double b) {

		double result = 0;
		
		for (int i = 0; i < a.length; i++) {
			result += (a[i] + b);
		}
		
		return result;
	}
	
	
	public static double[] arrayMultiply(double[] a, double[] b) {

		double[] result = new double[a.length];
		
		for (int i = 0; i < a.length; i++) {
			result[i] = a[i] * b[i];
		}
		
		return result;
	}
	
	
	public static double[] arrayDivideByScalar(double[] a, double b) {

		double[] result = new double[a.length];
		
		for (int i = 0; i < a.length; i++) {
			result[i] = a[i] / b;
		}
		
		return result;
	}
	
	
	public static int getArrayMinIndex(double[] data) {
		int minIndex = 0;
		double minValue = data[0];
		
		for (int i = 0; i < data.length; i++) {
			if (data[i] < minValue) {
				minIndex = i;
				minValue = data[i];
			}
		}
		return minIndex;
	}
	
	public static int getArrayMaxIndex(double[] data) {
		int maxIndex = 0;
		double maxValue = data[0];
		
		for (int i = 0; i < data.length; i++) {
			if (data[i] > maxValue) {
				maxIndex = i;
				maxValue = data[i];
			}
		}
		return maxIndex;
	}
	
	
	public static void printMatrix(double[][] a) {
		int rowNum = a.length;
		int columnNum = a[0].length;
		
		for (int i = 0; i < rowNum; i++) {
			for (int j = 0; j < columnNum; j++) {
				System.out.print(a[i][j]);
				System.out.print(" ");
			}
			System.out.println();
		}
	}
	
	public static void showMatrixInGUI(double[][] a) {
		Matrix d = MatrixFactory.importFromArray(a);
		d.showGUI();
	}
	
	/**
	 * 
	 */
	public MatrixUtils() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//double[][] a = randUniform2D(10, 2, 1);
		//printMatrix(a);
		//showMatrixInGUI(a);
		
		double[] a = {4, 3, 5};
		Arrays.sort(a);
		

	}

}
