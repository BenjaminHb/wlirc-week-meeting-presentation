/**
 * 
 */
package com.zhujiahui.util;

import java.util.ArrayList;

import org.ujmp.core.Matrix;

import com.mathworks.toolbox.javabuilder.MWException;
import com.mathworks.toolbox.javabuilder.MWNumericArray;

import matlabutils.MATLABUtils;

/**
 * @author ZhuJiahui705
 *
 */
public class MATLABJavaUtils {

	/**
	 * 
	 */
	public MATLABJavaUtils() {
		// TODO Auto-generated constructor stub
	}
	
	public static double[][] matrixMultiply(double[][] a, double[][] b) {
		
		Object[] output = new Object[1];
		Object[] input = new Object[2];
		input[0] = a;
		input[1] = b;
		
		try {
			MATLABUtils mu = new MATLABUtils();
			
			mu.matrixMultiply(output, input);
			
			
		} catch (MWException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		MWNumericArray temp = (MWNumericArray)output[0];
		double [][] result = (double [][])temp.toDoubleArray();
		
		return result;
	}
	
	
	public static double[][] pinv(double[][] a) {
		
		Object[] output = new Object[1];
		Object[] input = new Object[1];
		input[0] = a;
		
		try {
			MATLABUtils mu = new MATLABUtils();
			mu.matrixPseudoInverse(output, input);
		} catch (MWException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		MWNumericArray temp = (MWNumericArray)output[0];
		double [][] result = (double [][])temp.toDoubleArray();
		
		return result;
	}
	
	public static ArrayList<double[][]> svd(double[][] a) {
		Object[] output = new Object[3];
		Object[] input = new Object[1];
		input[0] = a;
		
		ArrayList<double[][]> result = new ArrayList<double[][]>(); 
		
		try {
			MATLABUtils mu = new MATLABUtils();			
			mu.singularValueDecomposition(output, input);
			
		} catch (MWException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		for (int i = 0; i < 3; i++) {
			MWNumericArray temp = (MWNumericArray)output[i];
			result.add((double [][])temp.toDoubleArray());
		}
		
		return result;
	}
	
	
	public static ArrayList<double[][]> svdMax(double[][] a, int maxNum) {
		Object[] output = new Object[3];
		Object[] input = new Object[2];
		input[0] = a;
		input[1] = (double) maxNum;
		
		ArrayList<double[][]> result = new ArrayList<double[][]>(); 
		
		try {
			MATLABUtils mu = new MATLABUtils();			
			mu.singularValueDecompositionMax(output, input);
			
		} catch (MWException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		for (int i = 0; i < 3; i++) {
			MWNumericArray temp = (MWNumericArray)output[i];
			result.add((double [][])temp.toDoubleArray());
		}
		
		return result;
	}
	
	
	public static ArrayList<double[][]> qr(double[][] a) {
		Object[] output = new Object[2];
		Object[] input = new Object[1];
		input[0] = a;
		
		ArrayList<double[][]> result = new ArrayList<double[][]>(); 
		
		try {
			MATLABUtils mu = new MATLABUtils();			
			mu.qrDecomposition(output, input);
			
		} catch (MWException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		for (int i = 0; i < 2; i++) {
			MWNumericArray temp = (MWNumericArray)output[i];
			result.add((double [][])temp.toDoubleArray());
		}
		
		return result;
	}
	
	public static ArrayList<double[][]> lu(double[][] a) {
		Object[] output = new Object[2];
		Object[] input = new Object[1];
		input[0] = a;
		
		ArrayList<double[][]> result = new ArrayList<double[][]>(); 
		
		try {
			MATLABUtils mu = new MATLABUtils();			
			mu.luDecomposition(output, input);
			
		} catch (MWException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		for (int i = 0; i < 2; i++) {
			MWNumericArray temp = (MWNumericArray)output[i];
			result.add((double [][])temp.toDoubleArray());
		}
		
		return result;
	} 
	
	
	/*
	public static double[][] transpose(double[][] a) {
		
		Object[] output = new Object[1];
		Object[] input = new Object[1];
		input[0] = a;
		
		try {
			MATLABUtils mu = new MATLABUtils();
			
			mu.transpose(output, input);
			
			
		} catch (MWException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		MWNumericArray temp = (MWNumericArray)output[0];
		double [][] result = (double [][])temp.toDoubleArray();
		
		return result;
	}
	*/
	
	/*
	public static double squareResidual(double[][] a, double[][] b) {
		
		Object[] output = new Object[1];
		Object[] input = new Object[2];
		input[0] = a;
		input[1] = b;
		
		try {
			MATLABUtils mu = new MATLABUtils();
			
			mu.squareResidual(output, input);
			
			
		} catch (MWException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		MWNumericArray temp = (MWNumericArray)output[0];
		double [][] result = (double [][])temp.toDoubleArray();
		
		return result[0][0];
	}
	*/
	
	/*
	public static double[][] matrixDivideByElement(double[][] a, double[][] b) {
		Object[] output = new Object[1];
		Object[] input = new Object[2];
		input[0] = a;
		input[1] = b;
		
		try {
			MATLABUtils mu = new MATLABUtils();
			
			mu.matrixDivideByElement(output, input);
			
			
		} catch (MWException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		MWNumericArray temp = (MWNumericArray)output[0];
		double [][] result = (double [][])temp.toDoubleArray();
		
		return result;
	}
	*/
	
	/*
	 * It is slower than the Random.nextDouble()
	public static double[][] randUniform(int m, int n, double scalar) {
		
		Object[] output = new Object[1];
		Object[] input = new Object[3];
		input[0] = (double) m;
		input[1] = (double) n;
		input[2] = scalar;
		
		try {
			MATLABUtils mu = new MATLABUtils();
			mu.randUniform(output, input);
		} catch (MWException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		MWNumericArray temp = (MWNumericArray)output[0];
		double [][] result = (double [][])temp.toDoubleArray();
		
		return result;
		
	}
	*/

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		double[][] a = MatrixUtils.randUniform2D(2000, 2000, 3.0);
		double[][] b = MatrixUtils.randUniform2D(2000, 2000, 5.0);
		//Matrix inn = Matrix.factory.randn(2000, 2000);
		long startTime = System.currentTimeMillis();
		//Matrix innv = inn.pinv();
		//double[][] c = transpose(a);
		//double[][] c = MatrixUtils.transpose(a);
		//double c = squareResidual(a, b);
		//double c = MatrixUtils.squareResidual(a, b);
		//MWNumericArray c = matrixMultipy2(a, b);
		//double[][] c = matrixMultipy(a, b);
		
		//ArrayList<double[][]> al = svd(a);
		//ArrayList<double[][]> al = qr(a);
		//ArrayList<double[][]> al = lu(a);
		double[][] c = pinv(a);
		
		long endTime = System.currentTimeMillis();
	    System.out.println("��������ʱ�䣺 " + (endTime - startTime) + "ms");

	}

}
