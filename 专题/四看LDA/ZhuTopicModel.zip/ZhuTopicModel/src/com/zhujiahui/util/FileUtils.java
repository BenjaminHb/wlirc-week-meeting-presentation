/**
 * 
 */
package com.zhujiahui.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Pattern;

import javax.swing.JOptionPane;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * @author ZhuJiahui705
 *
 */
public class FileUtils {

	/**
	 * 
	 */
	public FileUtils() {
		// TODO Auto-generated constructor stub
	}

	
	public static ArrayList<ArrayList<String>> readFromFileToString2DLL(String fileName) {
		
		File tf = new File(fileName);
		BufferedReader br = null;
		
		ArrayList<ArrayList<String>> dataList = new ArrayList<ArrayList<String>>();

		Pattern pattern = Pattern.compile("[\\t|\\s|,]");
		
		try {
			br = new BufferedReader(new FileReader(tf));
			
			String strLine = null;
			
			// ���ж�ȡ
			while ((strLine = br.readLine()) != null) {
				
				ArrayList<String> al = new ArrayList<String>();

				String [] splitStrings = pattern.split(strLine.trim());
				
				for (int i = 0; i < splitStrings.length; i++) {
					al.add(splitStrings[i]);
				}
				
				dataList.add(al);
				
			}
			br.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			// JOptionPane.showMessageDialog(null, "�ļ�û���ҵ�", "����", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			// JOptionPane.showMessageDialog(null, "�ļ���ȡ����", "����", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		
		return dataList;
	}
	
	
	public static ArrayList<ArrayList<String>> readFromFileToString2DLL(String fileName, String delimiter) {
		
		File tf = new File(fileName);
		BufferedReader br = null;
		
		ArrayList<ArrayList<String>> dataList = new ArrayList<ArrayList<String>>();
		
		try {
			br = new BufferedReader(new FileReader(tf));
			
			String strLine = null;
			
			// ���ж�ȡ
			while ((strLine = br.readLine()) != null) {
				
				
				String [] splitStrings = strLine.trim().split(delimiter);
				
				//ArrayList<String> al = new ArrayList<String>(Arrays.asList(splitStrings));
				ArrayList<String> al = new ArrayList<String>();
				
				
				for (int i = 0; i < splitStrings.length; i++) {
					al.add(splitStrings[i]);
				}
				
				
				dataList.add(al);
				
			}
			br.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			// JOptionPane.showMessageDialog(null, "�ļ�û���ҵ�", "����", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			// JOptionPane.showMessageDialog(null, "�ļ���ȡ����", "����", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		
		return dataList;
	}
	
	
    public static double[][] readFromFileToDouble2DAA(String fileName, String delimiter) {
		
		File tf = new File(fileName);
		BufferedReader br = null;
		
		ArrayList<double []> dataList2 = new ArrayList<double []>();
		
		try {
			br = new BufferedReader(new FileReader(tf));
			
			String strLine = null;
			
			// ���ж�ȡ
			while ((strLine = br.readLine()) != null) {

				String [] splitStrings = strLine.trim().split(delimiter);
				double [] doubleValues = new double[splitStrings.length];
				
				for (int i = 0; i < splitStrings.length; i++) {
					doubleValues[i] = Double.parseDouble(splitStrings[i]);
				}
				
				dataList2.add(doubleValues);
				
			}
			br.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			// JOptionPane.showMessageDialog(null, "�ļ�û���ҵ�", "����", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			// JOptionPane.showMessageDialog(null, "�ļ���ȡ����", "����", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		
		double[][] dataList = new double[dataList2.size()][];
		
		for (int i = 0; i < dataList2.size(); i++) {
			dataList[i] = dataList2.get(i);
		}
		
		return dataList;
	}
    
    
    
    public static double[][] readFromFileToDouble2DAA(String fileName, String delimiter, int rowNum) {
		
		File tf = new File(fileName);
		BufferedReader br = null;
		
		double[][] dataList = new double[rowNum][];
		
		int rowCount = 0;
		try {
			br = new BufferedReader(new FileReader(tf));
			
			String strLine = null;
			
			// ���ж�ȡ
			while ((strLine = br.readLine()) != null) {

				String [] splitStrings = strLine.trim().split(delimiter);
				double [] doubleValues = new double[splitStrings.length];
				
				for (int i = 0; i < splitStrings.length; i++) {
					doubleValues[i] = Double.parseDouble(splitStrings[i]);
				}
				
				dataList[rowCount] = doubleValues;
				
				rowCount++;
				
				if (rowCount >= rowNum) {
					break;
				}
			}
			br.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			// JOptionPane.showMessageDialog(null, "�ļ�û���ҵ�", "����", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			// JOptionPane.showMessageDialog(null, "�ļ���ȡ����", "����", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		
		return dataList;
	}
    
    
    
    public static ArrayList<double []> readFromFileToDouble2DLA(String fileName, String delimiter) {
		
		File tf = new File(fileName);
		BufferedReader br = null;
		
		ArrayList<double []> dataList = new ArrayList<double []>();
		
		try {
			br = new BufferedReader(new FileReader(tf));
			
			String strLine = null;
			
			// ���ж�ȡ
			while ((strLine = br.readLine()) != null) {
				
				
				String [] splitStrings = strLine.trim().split(delimiter);
				double [] doubleValues = new double[splitStrings.length];
				
				for (int i = 0; i < splitStrings.length; i++) {
					doubleValues[i] = Double.parseDouble(splitStrings[i]);
				}
				
				dataList.add(doubleValues);
				
			}
			br.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			// JOptionPane.showMessageDialog(null, "�ļ�û���ҵ�", "����", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			// JOptionPane.showMessageDialog(null, "�ļ���ȡ����", "����", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		
		return dataList;
	}
	
	
    public static ArrayList<ArrayList<String>> readFromFileToString2DLL(String fileName, String delimiter, int startColumn, int endColumn) {
		
		File tf = new File(fileName);
		BufferedReader br = null;
		
		ArrayList<ArrayList<String>> dataList = new ArrayList<ArrayList<String>>();
		
		try {
			br = new BufferedReader(new FileReader(tf));
			
			String strLine = null;
			
			// ���ж�ȡ
			while ((strLine = br.readLine()) != null) {
				
				ArrayList<String> al = new ArrayList<String>();
				String [] splitStrings = strLine.trim().split(delimiter);
				
				int thisLineLength = splitStrings.length;
				
				if (startColumn >= thisLineLength) {
					startColumn = 0;
				}
				if (endColumn > thisLineLength) {
					endColumn = thisLineLength;
				}
				if (endColumn == -1) {
					endColumn = thisLineLength;
				}
				
				for (int i = startColumn; i < endColumn; i++) {
					al.add(splitStrings[i]);
				}
				
				dataList.add(al);
				
			}
			br.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			// JOptionPane.showMessageDialog(null, "�ļ�û���ҵ�", "����", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			// JOptionPane.showMessageDialog(null, "�ļ���ȡ����", "����", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		
		return dataList;
	}
    
    
    
    public static ArrayList<String> readFromFileToString1DL(String fileName) {
		
		File tf = new File(fileName);
		BufferedReader br = null;
		
		ArrayList<String> dataList = new ArrayList<String>();
		
		try {
			br = new BufferedReader(new FileReader(tf));
			
			String strLine = null;
			
			// ���ж�ȡ
			while ((strLine = br.readLine()) != null) {
				dataList.add(strLine.trim());
			}
			br.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			// JOptionPane.showMessageDialog(null, "�ļ�û���ҵ�", "����", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			// JOptionPane.showMessageDialog(null, "�ļ���ȡ����", "����", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		
		return dataList;
	}
    
    
    public static ArrayList<String> readFromFileToString1DL(String fileName, String delimiter, int selectColumn) {
		
		File tf = new File(fileName);
		BufferedReader br = null;
		
		ArrayList<String> dataList = new ArrayList<String>();
		
		try {
			br = new BufferedReader(new FileReader(tf));
			
			String strLine = null;
			
			// ���ж�ȡ
			while ((strLine = br.readLine()) != null) {
				
				String [] splitStrings = strLine.trim().split(delimiter);
				
				int thisLineLength = splitStrings.length;
				
				if (selectColumn >= thisLineLength) {
					selectColumn = 0;
				}
				if (selectColumn == -1) {
					selectColumn = thisLineLength - 1;
				}
				
				dataList.add(splitStrings[selectColumn]);
				
			}
			br.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			// JOptionPane.showMessageDialog(null, "�ļ�û���ҵ�", "����", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			// JOptionPane.showMessageDialog(null, "�ļ���ȡ����", "����", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		
		return dataList;
	}
	
    
    public static double[] readFromFileToDouble1DA(String fileName) {
		
		File tf = new File(fileName);
		BufferedReader br = null;
		
		ArrayList<Double> dataList2 = new ArrayList<Double>();
		
		try {
			br = new BufferedReader(new FileReader(tf));
			
			String strLine = null;
			
			// ���ж�ȡ
			while ((strLine = br.readLine()) != null) {
				dataList2.add(Double.parseDouble(strLine.trim()));
			}
			br.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			// JOptionPane.showMessageDialog(null, "�ļ�û���ҵ�", "����", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			// JOptionPane.showMessageDialog(null, "�ļ���ȡ����", "����", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		
		double[] dataList = new double[dataList2.size()];
		for (int i = 0; i < dataList2.size(); i++) {
			dataList[i] = dataList2.get(i);
		}
		
		return dataList;
	}
    
    
    public static double[] readFromFileToDouble1DA(String fileName, String delimiter, int selectColumn) {
		
		File tf = new File(fileName);
		BufferedReader br = null;
		
		ArrayList<Double> dataList2 = new ArrayList<Double>();
		
		try {
			br = new BufferedReader(new FileReader(tf));
			
			String strLine = null;
			
			// ���ж�ȡ
			while ((strLine = br.readLine()) != null) {
				
				String [] splitStrings = strLine.trim().split(delimiter);
				
				if (selectColumn >= splitStrings.length) {
					selectColumn = 0;
				}
				if (selectColumn == -1) {
					selectColumn = splitStrings.length - 1;
				}
				
				dataList2.add(Double.parseDouble(splitStrings[selectColumn]));
			}
			br.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			// JOptionPane.showMessageDialog(null, "�ļ�û���ҵ�", "����", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			// JOptionPane.showMessageDialog(null, "�ļ���ȡ����", "����", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		
		double[] dataList = new double[dataList2.size()];
		for (int i = 0; i < dataList2.size(); i++) {
			dataList[i] = dataList2.get(i);
		}
		
		return dataList;
	}
    
    
    public static ArrayList<Double> readFromFileToDouble1DL(String fileName) {
		
		File tf = new File(fileName);
		BufferedReader br = null;
		
		ArrayList<Double> dataList = new ArrayList<Double>();
		
		try {
			br = new BufferedReader(new FileReader(tf));
			
			String strLine = null;
			
			// ���ж�ȡ
			while ((strLine = br.readLine()) != null) {
				dataList.add(Double.parseDouble(strLine.trim()));
			}
			br.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			// JOptionPane.showMessageDialog(null, "�ļ�û���ҵ�", "����", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			// JOptionPane.showMessageDialog(null, "�ļ���ȡ����", "����", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		
		return dataList;
	}
    
    
    public static void writeString2DLLToFile(String fileName, ArrayList<ArrayList<String>> dataList, String delimiter) {
		
		File tf = new File(fileName);
		BufferedWriter bw = null;	
		
		try {
			if ( !tf.exists()) {
				tf.createNewFile();
			}
			bw = new BufferedWriter(new FileWriter(tf));
			
			StringBuilder buffer = new StringBuilder();

			for (int i = 0; i < dataList.size(); i++) {

				ZhuStringUtils.join(buffer, dataList.get(i), delimiter);
				buffer.append("\n");
				
				bw.write(buffer.toString());
				bw.flush();
				buffer = new StringBuilder();
			}
			//bw.write(buffer.toString());
			
			bw.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			// JOptionPane.showMessageDialog(null, "�ļ�д�����", "����", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}
    
    
    public static void writeString2DLLToFileByColumn(String fileName, ArrayList<ArrayList<String>> dataList, String delimiter) {
		
		File tf = new File(fileName);
		BufferedWriter bw = null;	
		
		try {
			if ( !tf.exists()) {
				tf.createNewFile();
			}
			bw = new BufferedWriter(new FileWriter(tf));
			
			StringBuilder buffer = new StringBuilder();

			for (int i = 0; i < dataList.get(0).size(); i++) {
				
				for (int j = 0; j < dataList.size() - 1; j++) {
					buffer.append(dataList.get(j).get(i));
					buffer.append(delimiter);
				}
				
				buffer.append(dataList.get(dataList.size() - 1).get(i));
				buffer.append("\n");
			}
			bw.write(buffer.toString());
			
			bw.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			// JOptionPane.showMessageDialog(null, "�ļ�д�����", "����", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}
	
	
	public static void writeString2DLAToFile(String fileName, ArrayList<String[]> dataList, String delimiter) {
		
		File tf = new File(fileName);
		BufferedWriter bw = null;
		
		try {
			if ( !tf.exists()) {
				tf.createNewFile();
			}
			bw = new BufferedWriter(new FileWriter(tf));
			
			StringBuilder buffer = new StringBuilder();
			
			for (int i = 0; i < dataList.size(); i++) {
				ZhuStringUtils.join(buffer, dataList.get(i), delimiter);
				buffer.append("\n");
				
				bw.write(buffer.toString());
				bw.flush();
				buffer = new StringBuilder();
			}
			
			bw.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			// JOptionPane.showMessageDialog(null, "�ļ�д�����", "����", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}
	
	
	public static void writeString1DLToFile(String fileName, ArrayList<String> dataList) {
		
		File tf = new File(fileName);
		BufferedWriter bw = null;
		
		try {
			if ( !tf.exists()) {
				tf.createNewFile();
			}
			bw = new BufferedWriter(new FileWriter(tf));
			
			StringBuilder buffer = new StringBuilder();
			
			ZhuStringUtils.join(buffer, dataList, "\n");
			bw.write(buffer.toString());
			bw.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			// JOptionPane.showMessageDialog(null, "�ļ�д�����", "����", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}
	
	

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String fileName = "D:/58.txt";
		//ArrayList<ArrayList<String>> al = readFromFileToString2DLL(fileName, " ");
		ArrayList<String> al = readFromFileToString1DL(fileName);
		String fileName2 = "D:/write2.txt";
		
		long startTime = System.currentTimeMillis();
		//writeString2DLLToFile(fileName2, al, " ");
		writeString1DLToFile(fileName2, al);
		long endTime = System.currentTimeMillis();
		
		System.out.println("��������ʱ�䣺 " + (endTime - startTime) + "ms");
		
		/*
		for (int i = 0; i < 10; i++) {
			//System.out.println(StringUtils.join(al.get(i), "##"));
			System.out.println(al[i][2]);
		}
		
		System.out.println(al.length);*/

	}

}
