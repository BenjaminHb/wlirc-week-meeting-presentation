/**
 * 
 */
package com.zhujiahui.util;

import java.util.ArrayList;

/**
 * @author ZhuJiahui705
 *
 */
public class ZhuStringUtils {

	/**
	 * 
	 */
	public ZhuStringUtils() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public static String join(String[] array, String delimiter) {
		StringBuilder sb = new StringBuilder();
		
		for (int i = 0; i < array.length - 1; i++) {
			sb.append(array[i]);
			sb.append(delimiter);
		}
		sb.append(array[array.length - 1]);
		
		return sb.toString();
	}
	
	public static String join(ArrayList<String> al, String delimiter) {
		StringBuilder sb = new StringBuilder();
		
		for (int i = 0; i < al.size()- 1; i++) {
			sb.append(al.get(i));
			sb.append(delimiter);
		}
		sb.append(al.get(al.size() - 1));
		
		return sb.toString();
	}
	
	public static void join(StringBuilder sb, ArrayList<String> al, String delimiter) {
		for (int i = 0; i < al.size()- 1; i++) {
			sb.append(al.get(i));
			sb.append(delimiter);
		}
		sb.append(al.get(al.size() - 1));
	}
	
	public static void join(StringBuilder sb, String[] array, String delimiter) {
		for (int i = 0; i < array.length - 1; i++) {
			sb.append(array[i]);
			sb.append(delimiter);
		}
		sb.append(array[array.length - 1]);
	}

}
