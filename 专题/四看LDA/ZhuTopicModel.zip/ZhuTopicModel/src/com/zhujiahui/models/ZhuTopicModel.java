/**
 * 
 */
package com.zhujiahui.models;

import java.io.IOException;
import java.util.ArrayList;

import org.ujmp.core.Matrix;
import org.ujmp.core.MatrixFactory;

import com.zhujiahui.util.FileUtils;

import cc.mallet.pipe.*;
import cc.mallet.topics.ParallelTopicModel;
import cc.mallet.types.Alphabet;
import cc.mallet.types.Instance;
import cc.mallet.types.InstanceList;

/**
 * @author ZhuJiahui705
 *
 */
public class ZhuTopicModel {
	
	private int topicNum;
	/**
	 * 
	 */
	public ZhuTopicModel() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<ArrayList<String>> corpus = FileUtils.readFromFileToString2DLL("testFile/442.docs", " ");
		ArrayList<String> vocabulary = FileUtils.readFromFileToString1DL("testFile/442.vocab", ":", 0);
		Object[] volList = vocabulary.toArray();
		Alphabet alp = new Alphabet(volList);
		
		
		StringList2FeatureSequence sfs = new StringList2FeatureSequence(alp);
		InstanceList instances = new InstanceList(alp, null);
		
		for (int i = 0; i < corpus.size(); i++) {
			Instance ii = sfs.pipe(new Instance(corpus.get(i), null, String.valueOf(i), null));
			instances.add(ii);
		}
		
		long startTime = System.currentTimeMillis();
		ParallelTopicModel model = new ParallelTopicModel(10, 1.0, 0.01);
		model.addInstances(instances);
		model.setNumIterations(100);
		//model.setNumThreads(1);
		try {
			model.estimate();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		long endTime = System.currentTimeMillis();
	    System.out.println("��������ʱ�䣺 " + (endTime - startTime) + "ms");
		
		double[] aa = model.getTopicProbabilities(1);
		
		Matrix bb = MatrixFactory.importFromArray(model.getTopicWords(true, true));
		bb.showGUI();

	}

}
