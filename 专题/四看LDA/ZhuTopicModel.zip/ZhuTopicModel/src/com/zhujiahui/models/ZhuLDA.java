/**
 * 
 */
package com.zhujiahui.models;

import java.text.DecimalFormat;
import java.util.ArrayList;

import com.zhujiahui.util.FileUtils;
import com.zhujiahui.util.MatrixUtils;
import java.util.Random;

import org.ujmp.core.Matrix;

/**
 * @author ZhuJiahui705
 *
 */
public class ZhuLDA {
	
	private ArrayList<ArrayList<String>> corpus;
	private ArrayList<String> vocabulary;
	private int topicNum;
	private double alpha;
	private double beta;
	private double[][] theta;
	private double[][] phi;
	//private Matrix theta;
	//private Matrix phi;
	
	private int documentSize;
	private int vocabularySize; 

	
	
	public ZhuLDA(ArrayList<ArrayList<String>> corpus, ArrayList<String> vocabulary, int topicNum, double alpha,
			double beta) {
		super();
		this.corpus = corpus;
		this.documentSize = corpus.size();
		this.vocabulary = vocabulary;
		this.vocabularySize = vocabulary.size();
		
		this.topicNum = topicNum;
		this.alpha = alpha;
		this.beta = beta;
		this.theta = MatrixUtils.init2DDoubleArray(this.documentSize, this.topicNum, 0);
		this.phi = MatrixUtils.init2DDoubleArray(this.topicNum, this.vocabularySize, 0);
		//this.theta = Matrix.factory.zeros(this.documentSize, this.topicNum);
		//this.phi = Matrix.factory.zeros(this.topicNum, this.vocabularySize);
	}
	
	public ZhuLDA(ArrayList<ArrayList<String>> corpus, ArrayList<String> vocabulary, int topicNum) {
		super();
		this.corpus = corpus;
		this.documentSize = corpus.size();
		this.vocabulary = vocabulary;
		this.vocabularySize = vocabulary.size();
		
		this.topicNum = topicNum;
		this.alpha = 0.1;
		this.beta = 0.1;
		this.theta = MatrixUtils.init2DDoubleArray(this.documentSize, this.topicNum, 0);
		this.phi = MatrixUtils.init2DDoubleArray(this.topicNum, this.vocabularySize, 0);
		//this.theta = Matrix.factory.zeros(this.documentSize, this.topicNum);
		//this.phi = Matrix.factory.zeros(this.topicNum, this.vocabularySize);
	}

	private void inference(int mode) {
		switch (mode) {
		case 1: collapsedGibbsSampling(); break;
		case 2: variationalBayes(); break;
		default: collapsedGibbsSampling(); break;
		}
	}
	
	private void collapsedGibbsSampling() {
		
		// init topic assignment
		int iterations = 150;
		Random random = new Random();
		
		ArrayList<ArrayList<Integer>> Z = new ArrayList<ArrayList<Integer>>();
		for (int i = 0; i < documentSize; i++) {
			ArrayList<Integer> thisLine = new ArrayList<Integer>();
			for (int j = 0; j < corpus.get(i).size(); j++) {
				int zIndex = random.nextInt(topicNum - 1) % topicNum;
				thisLine.add(zIndex);
				
				int currentWordIndex = Integer.parseInt(corpus.get(i).get(j));
				// count + 1
				theta[i][zIndex] += 1;
				phi[zIndex][currentWordIndex] += 1;
			}
			Z.add(thisLine);
		}
		
		double[] topicCount = MatrixUtils.matrixSumByRow2(phi);
		
		// Gibbs sampling
		for (int t = 0; t < iterations; t++) {
			for (int i = 0; i < documentSize; i++) {
				for (int j = 0; j < corpus.get(i).size(); j++) {
					int currentWordIndex = Integer.parseInt(corpus.get(i).get(j));
					int currentZ = Z.get(i).get(j);
					
					// count - 1
					theta[i][currentZ] -= 1;
					phi[currentZ][j] -= 1;
					topicCount[currentZ] -= 1;
					
					// Prepare for P(Zdn|-Zdn)
					double[] Pz_dn_exclude = new double[topicNum];
					
					for (int k = 0; k < topicNum; k++) {
						Pz_dn_exclude[k] = (theta[i][k] + alpha) * (phi[k][currentWordIndex] + beta) 
								/ (topicCount[k] + beta * vocabularySize);
					}
					
					int updateTopicIndex = sample(Pz_dn_exclude);
					Z.get(i).set(j, updateTopicIndex);
					
					// count + 1
					theta[i][updateTopicIndex] += 1;
					phi[updateTopicIndex][j] += 1;
					topicCount[updateTopicIndex] += 1;
				}
			}
		}
		
		theta = MatrixUtils.matrixNormalizeByRow(theta);
		phi = MatrixUtils.matrixNormalizeByRow(phi);
		
	}
	
	private void variationalBayes() {
		
	}
	
	private int sample(double[] toSample) {
		
		double sampleSum = MatrixUtils.arraySum(toSample);
		double[] normalized = MatrixUtils.arrayDivideByScalar(toSample, sampleSum);
		
		Random rd = new Random();
		double randNum = rd.nextDouble();
		
		int index = -1;
		
		while (randNum > 0) {
			index += 1;
			randNum = randNum - normalized[index];
		}
		
		return index;
	}
	
	
	private void printTopics(int topNWords, String delimiter) {
		//double[][] result = new double[topicNum][vocabularySize];
		
		StringBuilder sb = new StringBuilder("");
		DecimalFormat df = new DecimalFormat("0.####");
		
		for (int i = 0; i < topicNum; i++) {
			double[] temp = new double[vocabularySize];
			for (int j = 0; j < vocabularySize; j++) {
				temp[j] = phi[i][j];
			}

			for (int j = 0; j < topNWords - 1; j++) {
				int maxIndex = MatrixUtils.getArrayMaxIndex(temp);
				sb.append(df.format(temp[maxIndex]));
				sb.append("*");
				sb.append(vocabulary.get(maxIndex));
				sb.append(delimiter);

				temp[maxIndex] = 0;
			}
			int maxIndex = MatrixUtils.getArrayMaxIndex(temp);
			sb.append(df.format(temp[maxIndex]));
			sb.append("*");
			sb.append(vocabulary.get(maxIndex));
			sb.append("\n");
			
		}
		
		System.out.println(sb.toString());
	}
	
	private void printTopics(double threshold, String delimiter) {
		//double[][] result = new double[topicNum][vocabularySize];
		
		StringBuilder sb = new StringBuilder("");
		DecimalFormat df = new DecimalFormat("0.####");
		
		for (int i = 0; i < topicNum; i++) {
			for (int j = 0; j < vocabularySize; j++) {
				if (phi[i][j] >= threshold) {
					sb.append(df.format(phi[i][j]));
					sb.append("*");
					sb.append(vocabulary.get(j));
					sb.append(delimiter);
				}
			}

			sb.append("\n");
		}
		
		System.out.println(sb.toString());
	}
	
	private double[][] thetaSparse(int sparsity) {

		double[][] result = new double[documentSize][topicNum];
		
		for (int i = 0; i < documentSize; i++) {
			double[] temp = new double[topicNum];
			for (int j = 0; j < topicNum; j++) {
				temp[j] = theta[i][j];
			}

			for (int j = 0; j < sparsity; j++) {
				int maxIndex = MatrixUtils.getArrayMaxIndex(temp);
				result[i][maxIndex] = temp[maxIndex];
				temp[maxIndex] = 0;
			}
			
		}
		
		return result;
	}
	
	
	private double[][] phiSparse(int sparsity) {

		double[][] result = new double[topicNum][vocabularySize];
		
		for (int i = 0; i < topicNum; i++) {
			double[] temp = new double[vocabularySize];
			for (int j = 0; j < vocabularySize; j++) {
				temp[j] = phi[i][j];
			}

			for (int j = 0; j < sparsity; j++) {
				int maxIndex = MatrixUtils.getArrayMaxIndex(temp);
				result[i][maxIndex] = temp[maxIndex];
				temp[maxIndex] = 0;
			}
			
		}
		
		return result;
	}



	public ArrayList<ArrayList<String>> getCorpus() {
		return corpus;
	}

	public void setCorpus(ArrayList<ArrayList<String>> corpus) {
		this.corpus = corpus;
	}

	public ArrayList<String> getVocabulary() {
		return vocabulary;
	}

	public void setVocabulary(ArrayList<String> vocabulary) {
		this.vocabulary = vocabulary;
	}

	public int getTopicNum() {
		return topicNum;
	}

	public void setTopicNum(int topicNum) {
		this.topicNum = topicNum;
	}

	public double getAlpha() {
		return alpha;
	}

	public void setAlpha(double alpha) {
		this.alpha = alpha;
	}

	public double getBeta() {
		return beta;
	}

	public void setBeta(double beta) {
		this.beta = beta;
	}

	public double[][] getTheta() {
		return theta;
	}

	public void setTheta(double[][] theta) {
		this.theta = theta;
	}

	public double[][] getPhi() {
		return phi;
	}

	public void setPhi(double[][] phi) {
		this.phi = phi;
	}

	public int getDocumentSize() {
		return documentSize;
	}

	public void setDocumentSize(int documentSize) {
		this.documentSize = documentSize;
	}

	public int getVocabularySize() {
		return vocabularySize;
	}

	public void setVocabularySize(int vocabularySize) {
		this.vocabularySize = vocabularySize;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<ArrayList<String>> corpus = FileUtils.readFromFileToString2DLL("testFile/442.docs", " ");
		ArrayList<String> vocabulary = FileUtils.readFromFileToString1DL("testFile/442.vocab", ":", 1);
		
		int topicNum = 10;
		double alpha = 0.1;
		double beta = 0.1;
		
		long startTime = System.currentTimeMillis();
		ZhuLDA zl = new ZhuLDA(corpus, vocabulary, topicNum, alpha, beta);
		zl.inference(1);
		
		long endTime = System.currentTimeMillis();
	    System.out.println("��������ʱ�䣺 " + (endTime - startTime) + "ms");
	    
	    zl.printTopics(10, " ");
		
		//MatrixUtils.showMatrixInGUI(zl.getTheta());
		MatrixUtils.showMatrixInGUI(zl.getPhi());

	}

}
